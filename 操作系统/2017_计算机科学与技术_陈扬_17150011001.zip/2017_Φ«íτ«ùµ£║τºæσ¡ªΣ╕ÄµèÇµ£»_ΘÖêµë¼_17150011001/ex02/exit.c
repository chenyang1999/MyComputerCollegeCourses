#include<stdlib.h>
#include<stdio.h>
int main()
{
	printf("this process will exit!\n");
	exit(0);
	printf("never be displayed!\n");
}

