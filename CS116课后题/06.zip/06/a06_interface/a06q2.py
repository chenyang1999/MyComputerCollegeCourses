def flatten(L):
  #YOUR CODE GOES HERE
  pass