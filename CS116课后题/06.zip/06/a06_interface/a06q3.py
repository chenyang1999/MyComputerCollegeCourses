def is_slime(num):
  #YOUR CODE GOES HERE
  pass