def near_palindrome(s, k):
  #YOUR CODE GOES HERE
  pass