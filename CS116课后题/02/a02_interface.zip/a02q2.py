def new_rating(ra, rb, sa, age_of_a, was_2400, num_games):
  #YOUR CODE GOES HERE
  pass