def full_isbn(n):
  #YOUR CODE GOES HERE
  pass