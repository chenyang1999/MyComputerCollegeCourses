def strange_sum(n):
  #YOUR CODE GOES HERE
  pass