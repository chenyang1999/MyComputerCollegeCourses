class PPM:
  def __init__(self, file_name):
    '''
    Fields: magic_number (Str), width (Nat), height(Nat),
            maxval (Nat), image (listof Nat)
    requires: 0 <=  maxval  <= 65536
              0 <= image[i] <= maxval  for all i in range(len(image))
    '''
    #YOUR CODE GOES HERE
    pass


  def __eq__(self, other):
    '''
    Returns true if and only if self and other have the same fields
    '''
    return isinstance(other, PPM) and \
           self.magic_number == other.magic_number and\
           self.width == other.width and\
           self.height == other.height and\
           self.maxval == other.maxval and\
           self.image == other.image
  
  def __repr__(self):
    '''
    Returns a string of the image
    '''
    return "Dimensions: ({0.width}, {0.height})\nImage: {0.image}".format(self)  
  
  def zero_out(self):
    #YOUR CODE GOES HERE
    pass