def encode_img(file_name, file_name_secret, file_name_out):
  #YOUR CODE GOES HERE
  pass

def decode_img(file_name, file_name_out):
  #YOUR CODE GOES HERE
  pass