def encode_msg(file_name, msg, file_name_out):
  #YOUR CODE GOES HERE
  pass
        
def decode_msg(file_name):
  #YOUR CODE GOES HERE
  pass