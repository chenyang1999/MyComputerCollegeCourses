def doubling_time(i):
  #YOUR CODE GOES HERE
  pass