def outer_radius(r, n):
  #YOUR CODE GOES HERE
  pass