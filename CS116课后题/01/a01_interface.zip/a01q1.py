def brine(num_eggs, egg_radius, jar_radius, jar_height):
  #YOUR CODE GOES HERE
  pass