def reverse(n):
  #YOUR CODE GOES HERE
  pass