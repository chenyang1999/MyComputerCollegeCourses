def obey_benford(L):
  #YOUR CODE GOES HERE
  pass