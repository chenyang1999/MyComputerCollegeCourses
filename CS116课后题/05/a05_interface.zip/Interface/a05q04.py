def recaman(n):
  #YOUR CODE GOES HERE
  pass