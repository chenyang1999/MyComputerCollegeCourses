def num_zeroes(L):
  #YOUR CODE GOES HERE
  pass