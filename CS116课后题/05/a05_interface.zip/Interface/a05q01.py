def grow_word(s):
  #YOUR CODE GOES HERE
  pass