def recaman(n):
  #YOUR CODE GOES HERE
  i=1
  r[0]=0
  while i <=n:
    if i>0 and r[i-1]-i>=0 and r[i-1]-i not in r[0:i]:
      r[i]=r[i-1]-i
    else:
      r[i]=r[i-1]+i
    print(r)
    i=i+1
  return r[n]
  
n=6
r=[-1]*(n+10)
print(r)
ans=recaman(n)
print(ans)