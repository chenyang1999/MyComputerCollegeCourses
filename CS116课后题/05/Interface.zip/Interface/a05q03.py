def num_zeroes(L):
  #YOUR CODE GOES HERE
  sum=1
  for i in L:
    sum=sum*i
  cnt=0
#  print(sum)
  while sum%10 ==0:
    cnt=cnt+1
    sum=sum/10
#    print(cnt,sum)
  return cnt

L=[2, 5, 6, 100]
ans=num_zeroes(L)
print(ans)