def is_anagram(s, t):
  #YOUR CODE GOES HERE
  pass