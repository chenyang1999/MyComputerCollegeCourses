def hawaiian_braille(s):
  #YOUR CODE GOES HERE
  pass