def valid_password(s):
  #YOUR CODE GOES HERE
  pass