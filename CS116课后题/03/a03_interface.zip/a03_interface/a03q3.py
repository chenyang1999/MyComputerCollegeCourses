num_prompt = "Enter a number of directions to be entered: "
dir_prompt = "Enter a direction (N, E, W, S): "
final_answer = "The distance from the origin is {0:0.3f} units."

def distance_from_origin():
  #YOUR CODE GOES HERE
  pass