#Important Text Constants
wager_prompt = "Enter a wager between 0 and {0}: "
next_card_prompt = "Is the next card higher or lower than {0}? "
first_card_text = "Your first card is a {0}."
current_card_text = "The card is a {0}."
current_bank_text = "You now have {0} dollars."
correct_text = "You are correct! " + current_bank_text
incorrect_text = "You are incorrect. " + current_bank_text
push_text = "Push. " + current_bank_text
last_card_text = "Last card."

def bonus_round(cards):
  #YOUR CODE GOES HERE
  pass