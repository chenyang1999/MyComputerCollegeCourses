def first_and_last(L):
  #YOUR CODE GOES HERE
  pass