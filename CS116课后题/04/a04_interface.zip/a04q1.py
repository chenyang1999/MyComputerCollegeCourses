def tsunami(s):
  #YOUR CODE GOES HERE
  pass