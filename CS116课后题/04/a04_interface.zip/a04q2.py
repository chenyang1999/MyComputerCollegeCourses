def reversal(s):
  #YOUR CODE GOES HERE
  pass